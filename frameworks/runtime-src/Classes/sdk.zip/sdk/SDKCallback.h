//
//  SDKCallback.h
//  hope
//
//  Created by yons on 15/8/25.
//
//

#ifndef __hope__SDKCallback__
#define __hope__SDKCallback__

#include <stdio.h>

class SDKCallback
{
public:
    static void callFromAndroid(const char* info);
};

#endif /* defined(__hope__SDKCallback__) */
