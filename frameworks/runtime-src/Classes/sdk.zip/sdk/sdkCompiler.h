//
//  sdkCompiler.h
//  hope
//
//  Created by yons on 15/8/25.
//
//

#ifndef hope_sdkCompiler_h
#define hope_sdkCompiler_h


#ifdef COMBINE_SDK
#define USING_SDK       1
#else
#define USING_SDK       0
#endif


#endif
